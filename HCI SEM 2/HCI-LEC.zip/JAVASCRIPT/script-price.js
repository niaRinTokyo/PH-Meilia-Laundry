function filter_all(){
    document.getElementById('pakaian-data').style.display = 'block'
    document.getElementById('bedcover-data').style.display = 'block'
    document.getElementById('boneka-data').style.display = 'block'
    document.getElementById('karpet-tikar-data').style.display = 'block'
    document.getElementById('jas-kasur-data').style.display = 'block'
    document.getElementById('sprei-selimut-data').style.display = 'block'
    document.getElementById('item-lain-data').style.display = 'block'
}

function filter_pakaian(){
    document.getElementById('pakaian-data').style.display = 'block'
    document.getElementById('bedcover-data').style.display = 'none'
    document.getElementById('boneka-data').style.display = 'none'
    document.getElementById('karpet-tikar-data').style.display = 'none'
    document.getElementById('jas-kasur-data').style.display = 'none'
    document.getElementById('sprei-selimut-data').style.display = 'none'
    document.getElementById('item-lain-data').style.display = 'none'
}

function filter_bedcover(){
    document.getElementById('pakaian-data').style.display = 'none'
    document.getElementById('bedcover-data').style.display = 'block'
    document.getElementById('boneka-data').style.display = 'none'
    document.getElementById('karpet-tikar-data').style.display = 'none'
    document.getElementById('jas-kasur-data').style.display = 'none'
    document.getElementById('sprei-selimut-data').style.display = 'none'
    document.getElementById('item-lain-data').style.display = 'none'
}

function filter_boneka(){
    document.getElementById('pakaian-data').style.display = 'none'
    document.getElementById('bedcover-data').style.display = 'none'
    document.getElementById('boneka-data').style.display = 'block'
    document.getElementById('karpet-tikar-data').style.display = 'none'
    document.getElementById('jas-kasur-data').style.display = 'none'
    document.getElementById('sprei-selimut-data').style.display = 'none'
    document.getElementById('item-lain-data').style.display = 'none'
}


function filter_karpet_tikar(){
    document.getElementById('pakaian-data').style.display = 'none'
    document.getElementById('bedcover-data').style.display = 'none'
    document.getElementById('boneka-data').style.display = 'none'
    document.getElementById('karpet-tikar-data').style.display = 'block'
    document.getElementById('jas-kasur-data').style.display = 'none'
    document.getElementById('sprei-selimut-data').style.display = 'none'
    document.getElementById('item-lain-data').style.display = 'none'
}


function filter_jas_kasur(){
    document.getElementById('pakaian-data').style.display = 'none'
    document.getElementById('bedcover-data').style.display = 'none'
    document.getElementById('boneka-data').style.display = 'none'
    document.getElementById('karpet-tikar-data').style.display = 'none'
    document.getElementById('jas-kasur-data').style.display = 'block'
    document.getElementById('sprei-selimut-data').style.display = 'none'
    document.getElementById('item-lain-data').style.display = 'none'
}

function filter_sprei_selimut(){
    document.getElementById('pakaian-data').style.display = 'none'
    document.getElementById('bedcover-data').style.display = 'none'
    document.getElementById('boneka-data').style.display = 'none'
    document.getElementById('karpet-tikar-data').style.display = 'none'
    document.getElementById('jas-kasur-data').style.display = 'none'
    document.getElementById('sprei-selimut-data').style.display = 'block'
    document.getElementById('item-lain-data').style.display = 'none'
}

function filter_itemLain(){
    document.getElementById('pakaian-data').style.display = 'none'
    document.getElementById('bedcover-data').style.display = 'none'
    document.getElementById('boneka-data').style.display = 'none'
    document.getElementById('karpet-tikar-data').style.display = 'none'
    document.getElementById('jas-kasur-data').style.display = 'none'
    document.getElementById('sprei-selimut-data').style.display = 'none'
    document.getElementById('item-lain-data').style.display = 'block'
}




